# q2.py

#
# Full Name:
#  SFU ID #:
# SFU Email:
#

# ... put your answer to question 2 here ...
