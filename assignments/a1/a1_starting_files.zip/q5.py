# q5.py

#
# Full Name:
#  SFU ID #:
# SFU Email:
#

# ... put your answer to question 5 here ...
